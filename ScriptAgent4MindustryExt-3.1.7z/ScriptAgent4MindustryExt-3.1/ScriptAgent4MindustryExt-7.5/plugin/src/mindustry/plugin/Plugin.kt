package mindustry.plugin

//兼容For 5.0
open class Plugin : mindustry.mod.Plugin()