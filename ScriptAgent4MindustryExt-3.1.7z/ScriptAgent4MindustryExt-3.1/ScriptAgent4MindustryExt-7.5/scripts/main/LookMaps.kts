@file:Depends("coreMindustry")
@file:Depends("coreMindustry/utilNext", "调用菜单")
@file:Depends("wayzer/user/userService")

package main

import arc.struct.ObjectFloatMap
import arc.struct.ObjectIntMap
import arc.util.serialization.Jval
import cf.wayzer.placehold.DynamicVar
import coreLibrary.lib.util.loop
import mindustry.world.blocks.legacy.LegacyCommandCenter.CommandBuild
import wayzer.VoteService
import java.net.URL

name = "地图站列表获取"

val menu = contextScript<coreMindustry.UtilNext>()
val playerpage: ObjectIntMap<String> = ObjectIntMap()//玩家个人翻页数
val canscore: ObjectIntMap<String> = ObjectIntMap()//能否投票
val mapscore: ObjectFloatMap<String> = ObjectFloatMap()//地图评分
val mapevaluates: ObjectIntMap<String> = ObjectIntMap()//地图评分
val usedtimes: ObjectIntMap<String> = ObjectIntMap()//玩家使用频率
val maxusedtime by config.key(200, "每小时最大申请允许次数")
fun Player.getusedtimes():Int{
    return usedtimes.get(uuid())
}
fun Player.mapcanvote(mapid:String,amount:Int) {
    val str = uuid()+mapid
    return canscore.put(str,amount)
}//是否可以投票 控制
fun Player.getcanvote(mapid:String): Int{
    val str = uuid()+mapid
    return canscore.get(str)
}//获取是否可以 投票
fun setmapevaluates(mapid:String,amount:Int) {
    return mapevaluates.put(mapid,mapevaluates.get(mapid) + amount)
}//地图总投票人数 控制
fun setmapscores(mapid:String,amount:Int) {
    val all = mapscore.get(mapid, 0F)*mapevaluates.get(mapid)
    return mapscore.put(mapid,(all+amount)/(mapevaluates.get(mapid)+1))
}//地图评分 控制
fun getmapscores(mapid:String):Float{
    return mapscore.get(mapid, 0F)
}
fun Player.getplayerpage():Int {
    return playerpage.get(uuid())
}
fun Player.previousPage(){
    return playerpage.put(uuid(),playerpage.get(uuid()) - 6)
}
fun Player.nextPage(){
    return playerpage.put(uuid(),playerpage.get(uuid()) + 6)
}
var json: Jval.JsonArray? = null
var serverpage: Int = 0
fun map(){
    try {
        val text = URL("https://mdt.wayzer.top/api/maps/list?begin=${(serverpage.toString())}").readText()
        json = Jval.read(text).asArray()
        ///broadcast("进行一次请求$page${json?.size}".with())///请求cs用
    }catch (e: Throwable){
        broadcast("wz站拒绝了你的请求".with())
    }
}//防止高强度请求
fun mapinfo(page:Int):String{
    if(page !in serverpage..serverpage+15){ serverpage = (page/15)*15 ;map() }
    val page = page%15
    val json = json?.get(page)
    val name = json?.get("name").toString()
    val id = json?.get("id").toString()
    val mode = json?.get("tags")?.asArray()?.get(1).toString()
    var mapscore = String.format("%.2f",getmapscores(id)) ;if(getmapscores(id) == 0f || (mapevaluates.get(id) < 1)) mapscore = "暂无"
    return "id:$id,评分:$mapscore,name:$name\n$mode"
}
fun moremapinfo(page:Int):String{
    if(page !in serverpage..serverpage+15){ serverpage = (page/15)*15 ;map() }
    val page = page % 15
    val json = json?.get(page)
    val name = json?.get("name").toString()
    val id = json?.get("id").toString()
    val tag = json?.get("tags")?.asArray().toString()
    val desc = json?.get("desc").toString()
    var mapscore = String.format("%.2f",getmapscores(id)) ;if(getmapscores(id) == 0f || mapevaluates.get(id) > 5) mapscore = "暂无"
    var mapevaluates = mapevaluates.get(id)
    return "id:$id,name:$name,评分:$mapscore\n共有$mapevaluates:人评分\n$desc\n$tag"
}
fun mapid(page:Int):String{
    if(page !in serverpage..serverpage+15){ serverpage = (page/15)*15 ;map() }
    var page = page % 15
    val json = json?.get(page)
    val id = json?.get("id").toString()
    return id
}
command("LookMaps", "查看地图") {
    usage = "[可选说明]"
    type = CommandType.Client
    aliases = listOf("查看地图")
    permission = "LookMaps"
    body{
        if(!(this.player?.admin())!!) {
            if (this.player?.getusedtimes() ?: 0 >= maxusedtime) {
                returnReply("你在一个小时中使用了${this.player?.getusedtimes() ?: 0}次请在一个小时后再试".with())
            }
        }
        this.player?.Menu(this.player!!)
        usedtimes.put(this.player?.uuid() ?: null,usedtimes.get(this.player?.uuid() ?: null)+1)
    }
}
suspend fun Player.Menu( player: Player ) {
    menu.sendMenuBuilder<Unit>(
        this, 30_000, "[red]注意不要频繁使用",
        """
            wz站有几率拒绝你的高强度请求
            每小时每人只允许查看$maxusedtime 次
            在一小时中你已经查看了${getusedtimes()}
        """.trimIndent()
    ) {
        for(page in 0+getplayerpage()..5+getplayerpage()){
            this += listOf(
                "${mapinfo(page)}" to {
                    moreMenu(player,page)
                }
            )
        }
        this += listOf(
            "[green][上一页]" to {
                if(getplayerpage() >= 6) {
                    previousPage()
                    Menu(player)
                    usedtimes.put(uuid(),usedtimes.get(uuid())+1)
                } else {
                    sendMessage("[red]没有上一页了")
                    Menu(player)
                }
            },
            "[green][下一页]" to {
                nextPage()
                Menu(player)
                usedtimes.put(uuid(),usedtimes.get(uuid())+1)
            }
        )
        this += listOf(
            "[green][回到首页]" to {
                playerpage.put(uuid(),0)
                Menu(player)
                usedtimes.put(uuid(),usedtimes.get(uuid())+1)
            }
        )
    }
}
suspend fun Player.moreMenu( player: Player , page:Int) {
    menu.sendMenuBuilder<Unit>(
        this, 30_000, "[red]别nm动不动换图",
        """
            ${moremapinfo(page)}
        """.trimIndent()
    ){
        this += listOf(
            "[green]投票换图${mapid(page)}" to {
            },"[red]返回" to {
                Menu(player)
            }
        )
        if(getcanvote(mapid(page)) >= 0) {
            this += listOf(
                "[green]为地图评分${mapid(page)}" to {
                    evaluateMenu(player,page)
                }
            )
        }else {
            this += listOf(
                "[green]你已经评分过了${mapid(page)}" to {
                }
            )
        }
    }
}
suspend fun Player.evaluateMenu(player:Player, page:Int) {
    menu.sendMenuBuilder<Unit>(
        this, 30_000, "[red]请认真评价",
        """
            满分5分
        """.trimIndent()
    ){
        for(score in 1..5){
            this += listOf(
                "[green]评分$score->map:${mapid(page)}" to {
                    setmapscores(mapid(page), score)
                    setmapevaluates(mapid(page), 1)
                    mapcanvote(mapid(page),-1)
                    Menu(player)
                }
            )
        }
    }
}
registerVar("scoreBroad.ext.contentsVersion", "提示", DynamicVar.v {
    "输入\"/LookMaps\"可以查看地图站地图"
})
onEnable{
    launch{
        loop(Dispatchers.game){
            map()
            playerpage.clear()
            usedtimes.clear()
            delay(60_000*60)
        }//每小时进行一次重置
    }
}
///服务器重启数据没了咋办？谁会在意。反正我不在意
PermissionApi.registerDefault("LookMaps")