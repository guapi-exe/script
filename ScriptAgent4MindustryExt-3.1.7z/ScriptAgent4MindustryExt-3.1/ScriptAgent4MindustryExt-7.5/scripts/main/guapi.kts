@file:Depends("coreMindustry")
package main

import arc.graphics.Color
import arc.struct.ObjectMap
import arc.util.Time
import arc.util.serialization.Jval
import coreLibrary.lib.util.loop
import mindustry.Vars
import mindustry.content.Fx
import mindustry.core.Version
import mindustry.game.Team
import mindustry.gen.Groups
import java.lang.Math.pow
import java.net.URL
import java.security.MessageDigest
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.sin

val playereffect: ObjectMap<String,Boolean> = ObjectMap()
val playertx: ObjectMap<String,Boolean> = ObjectMap()
val playerstring: ObjectMap<String,String> = ObjectMap()
val colors = arrayOf(
    "black",
    "red",
    "green",
    "yellow",
    "blue",
    "purple",
    "white"
)//所有颜色摘自wz colorapi所以请不用自行添加
name = " guapi秘制"
fun Tailing(x: Float,y: Float,str: String){
    val lasttime = Time.millis()
    launch(Dispatchers.game) {
        while (true) {
            if (Time.millis() - lasttime >= 1_000) break
            for (player in Groups.player.filter { it.unit().within(x, y, 300f) }) {
                Call.label(
                    player.con ?: return@launch,
                    "[${colors.random()}]$str", 0.8f,
                    x, y
                )
            }
            delay(1000)
        }
        Call.effect(Fx.healBlock, x, y, 10f, Color.green)
    }
}
onEnable{
    launch {
        loop(Dispatchers.game) {
            for (p in Groups.player) {
                var lastX = p.x
                var lastY = p.y
                launch(Dispatchers.game) {
                    while (true) {
                        if (p.unit() == null || state.rules.pvp || p.team() == Team.get(255) || playerstring.get(p.uuid()) == null) break
                        if (playereffect.get(p.uuid()) == false) break
                        for (str in "${playerstring.get(p.uuid())}") {
                            delay(200)
                            Tailing(p.x,p.y,str.toString())
                        }
                        if (lastX in p.x - 1f..p.x + 1f && lastY in p.y - 1f..p.y + 1f) break
                        lastX = p.x
                        lastY = p.y
                    }
                }
            }
            delay(2000)
        }
    }
}
command("guapi","烟花"){
    body{
        if (player == null) return@body
        val (x, y) = player!!.unit().let { it.x to it.y }
        arg.getOrNull(0)?.toIntOrNull()?.let { r ->
            (0 until 360).forEach { i ->
                val sinx = (sin(i.toDouble()) * r).toFloat()
                val cosy = (cos(i.toDouble()) * r).toFloat()
                Call.effect(Fx.healBlock,sinx + x,cosy + y, 10f, Color.green)
            }
        } ?: returnReply("请输入正确的半径".with())
    }
}
command("effect","拖尾"){
    usage = "是否开启拖尾"
    body{
        if(player == null ) return@body
        arg.getOrNull(0)?.toBoolean()?.let{
            if(playerstring.get(player!!.uuid()) == null ) returnReply("你还没有自定义你的专属拖尾文字".with())
            playereffect.put(player!!.uuid(),it)
            player.sendMessage("$it")
        }?:returnReply("请输入\"true\"or\"false\"".with())
    }
}
command("effectfly","特效"){
    usage = "是否开启特效"
    body{
        if(player == null ) return@body
        arg.getOrNull(0)?.toBoolean()?.let{
            playertx.put(player!!.uuid(),it)
            player.sendMessage("$it")
        }?:returnReply("请输入\"true\"or\"false\"".with())
    }
}
command("effectString","特效文字"){
    usage = "输入特效文字"
    body{
        if(player == null )returnReply("未找到玩家".with())
        arg.getOrNull(0)?.toString()?.let{ str ->
            playerstring.put(player!!.uuid(),str)
            playereffect.put(player!!.uuid(),true)
            player.sendMessage("写入成功，已经自动开启")
        }?: returnReply("请输入完整的文字".with())
    }
}
listen<EventType.PlayerJoin> { p ->
    if(playerstring.get(p.player.uuid()) == null ) playereffect.put(p.player.uuid(),false)
}
PermissionApi.registerDefault("guapi")
onEnable{
    launch(Dispatchers.game) {
        loop {
            for (player in Groups.player) {
                if (playertx.get(player.uuid())) {
                    drawButterfly(60f,player)
                }
            }
            delay(60*1_000)
        }
    }
}
suspend fun drawButterfly(size:Float,player:Player){
    var i = 0.0
    while(i <= 280) {
        i+=0.01
        val x = (player.unit().x +
                (sin(i)*
                        (exp(cos( i )) - 2 * cos(4 * i) - pow(sin(i / 12), 5.0)
                                ))*size).toFloat()
        val y = -1 * (player.unit().y +
                (cos(i)*
                        (exp(cos( i )) - 2 * cos(4 * i) - pow(sin(i / 12), 5.0)
                                ))*size).toFloat()
        Call.effect(Fx.colorTrail,y,x,10f, Color.gold)
    }
    delay(10)
    if(playertx.get(player.uuid())) drawButterfly(size,player)
}




