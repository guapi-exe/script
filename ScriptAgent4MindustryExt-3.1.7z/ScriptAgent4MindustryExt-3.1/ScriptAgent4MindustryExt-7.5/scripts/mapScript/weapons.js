UnitTypes.emanate.weapons.add(UnitTypes.stell.weapons.get(0));
UnitTypes.corvus.weapons.add(UnitTypes.corvus.weapons.get(0))