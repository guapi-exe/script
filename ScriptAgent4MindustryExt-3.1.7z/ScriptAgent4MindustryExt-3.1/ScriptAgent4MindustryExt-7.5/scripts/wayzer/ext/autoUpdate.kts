package wayzer.ext

import arc.util.Interval
import arc.util.Log
import arc.util.serialization.Jval
import cf.wayzer.placehold.PlaceHoldApi.with
import coreLibrary.lib.util.loop
import mindustry.Vars
import mindustry.core.Version
import mindustry.gen.Groups
import mindustry.net.BeControl
import java.io.File
import java.net.URL
import java.nio.file.Files
import java.time.LocalDateTime
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.system.exitProcess

name = "自动更新"

val enableUpdate by config.key(false, "是否开启自动更新")
val enabledataback by config.key(true, "是否开启自动更新")
val source by config.key("Anuken/Mindustry", "服务端来源，Github仓库")
val onlyInNight by config.key(false, "仅在凌晨自动更新", "本地时间1:00到7:00")
val useMirror by config.key(false, "使用镜像加速下载")

var updateCallback: (() -> Unit)? = null

suspend fun download(url: String, file: File): Int = withContext(Dispatchers.IO) {
    val steam = URL(url).openStream()
    val buffer = ByteArray(128 * 1024)//128KB
    val logInterval = Interval()
    var len = 0
    steam.use { input ->
        file.outputStream().use { output ->
            while (isActive) {
                val i = input.read(buffer)
                if (i == -1) break
                output.write(buffer, 0, i)
                len += i
                if (logInterval[60f])
                    logger.info("Downloaded ${len / 1024}KB")
            }
        }
    }
    return@withContext len
}

onEnable {
    loop {
        if (enableUpdate) {
            if (!onlyInNight || LocalDateTime.now().hour in 1..6)
                try {
                    val txt = URL("https://api.github.com/repos/$source/releases").readText()
                    val json = Jval.read(txt).asArray().first()
                    val newBuild = json.getString("tag_name", "")
                    val (version, revision) = ("$newBuild.0").removePrefix("v")
                        .split(".").map { it.toInt() }
                    if (version > Version.build || revision > Version.revision) {
                        val asset = json.get("assets").asArray().find {
                            it.getString("name", "").contains("server", ignoreCase = true)
                        } ?: error("New version $newBuild, but can't find asset")
                        val url = asset.getString("browser_download_url", "")
                        try {
                            update(newBuild, if (useMirror) "https://gh.tinylake.tk/$url" else url)
                            cancel()
                        } catch (e: Throwable) {
                            logger.warning("下载更新失败: $e")
                            e.printStackTrace()
                        }
                    }
                } catch (e: Throwable) {
                    logger.warning("获取更新数据失败: $e")
                }
        }
        delay(5 * 60_000)//延时5分钟
    }
}

onEnable {
    loop {
        if (enableUpdate) {
            if (!onlyInNight || LocalDateTime.now().hour in 1..6)
                try {
                    val txt = URL("https://api.github.com/repos/$source/releases").readText()
                    val json = Jval.read(txt).asArray().first()
                    val newBuild = json.getString("tag_name", "")
                    val (version, revision) = ("$newBuild.0").removePrefix("v")
                        .split(".").map { it.toInt() }
                    if (version > Version.build || revision > Version.revision) {
                        val asset = json.get("assets").asArray().find {
                            it.getString("name", "").contains("server", ignoreCase = true)
                        } ?: error("New version $newBuild, but can't find asset")
                        val url = asset.getString("browser_download_url", "")
                        try {
                            update(newBuild, if (useMirror) "https://gh.tinylake.tk/$url" else url)
                            cancel()
                        } catch (e: Throwable) {
                            logger.warning("下载更新失败: $e")
                            e.printStackTrace()
                        }
                    }
                } catch (e: Throwable) {
                    logger.warning("获取更新数据失败: $e")
                }
        }
        delay(5 * 60_000)//延时5分钟
    }
}
val scheduler = Executors.newSingleThreadScheduledExecutor()
scheduler.scheduleAtFixedRate(
    {
        if(enabledataback) {
            val metadata = Vars.dataDirectory.child("scripts").child("metadata").file()
            val data = Vars.dataDirectory.child("scripts").child("data").file()
            val databack = Vars.dataDirectory.child("databack").child("data").file()
            if (!databack.exists()) {
                databack.mkdirs()
                data.copyRecursively(databack.resolveSibling("${LocalDateTime.now()}|data.tmp"), true)
                metadata.copyRecursively(databack.resolveSibling("${LocalDateTime.now()}|metadata.tmp"), true)
            } else {
                data.copyRecursively(databack.resolveSibling("${LocalDateTime.now()}|data.tmp"), true)
                metadata.copyRecursively(databack.resolveSibling("${LocalDateTime.now()}|metadata.tmp"), true)
            }
        }
    },
    0L, // 只执行一次
    24 * 60 * 60 * 1000L, // 24小时执行一次
    TimeUnit.MILLISECONDS)
command("SaveDatabase", "强制保存数据库") {
    permission = dotId
    body {
        val metadata = Vars.dataDirectory.child("scripts").child("metadata").file()
        val data = Vars.dataDirectory.child("scripts").child("data").file()
        val databack = Vars.dataDirectory.child("databack").child("data").file()
        if (!databack.exists()) {
            databack.mkdirs()
            data.copyRecursively(databack.resolveSibling("${LocalDateTime.now()}|data.tmp"), true)
            metadata.copyRecursively(databack.resolveSibling("${LocalDateTime.now()}|metadata.tmp"), true)
        } else {
            data.copyRecursively(databack.resolveSibling("${LocalDateTime.now()}|data.tmp"), true)
            metadata.copyRecursively(databack.resolveSibling("${LocalDateTime.now()}|metadata.tmp"), true)
        }
    }
}
command("Enabledatabase", "启用新的数据库") {
    permission = dotId
    body {
        val filename = ArrayList<String>()
        val datatime = arg.getOrNull(0)?.toString()?:let{
            val list = dataDirectory.child("databack").file()
            for (file in list.walk()) {
                if(file.isFile){
                    filename.add(file.name+"\n")
                }
            }//这段没用跑不了子文件夹
            returnReply("$filename".with())
        }
        filename.clear()
        val metadata = Vars.dataDirectory.child("scripts").child("metadata").file()
        val data = Vars.dataDirectory.child("scripts").child("data").file()
        val databack = Vars.dataDirectory.child("databack").child("data").file()
        if (!databack.exists()) {
            databack.mkdirs()
            data.copyRecursively(databack.resolveSibling("${LocalDateTime.now()}|data.tmp"), true)
            metadata.copyRecursively(databack.resolveSibling("${LocalDateTime.now()}|metadata.tmp"), true)
        } else {
            data.copyRecursively(databack.resolveSibling("${LocalDateTime.now()}|data.tmp"), true)
            metadata.copyRecursively(databack.resolveSibling("${LocalDateTime.now()}|metadata.tmp"), true)
        }//再使用备份数据库时再就行一次备份
        delay(1000)
        val newdata = Vars.dataDirectory.child("databack").child("${datatime}|data.tmp").file()
        val newdetadata = Vars.dataDirectory.child("databack").child("${datatime}|metadata.tmp").file()
        if(!newdata.exists() || !newdetadata.exists()){ returnReply("未找到备份文件".with()) }
        val config = Vars.dataDirectory.child("scripts").child("data").file()
        newdata.copyTo(config.resolveSibling("data"), true)
        newdetadata.copyTo(config.resolveSibling("metadata"), true)
    }
}
suspend fun update(version: String, url: String) {
    Log.info("发现新版本可用 $version 正在从 $url 下载")
    val dest = File(BeControl::class.java.protectionDomain.codeSource.location.toURI().path)
    val tmp = dest.resolveSibling("server-$version.jar.tmp")
    val size = try {
        download(url, tmp)
    } catch (e: Throwable) {
        tmp.delete()
        throw e
    }
    Log.info("新版本 $version 下载完成: ${size / 1024}KB")
    updateCallback = {
        Groups.player.forEach {
            it.kick("[yellow]服务器重启更新到新版本 $version")
        }

        Thread.sleep(100L)
        dest.outputStream().use { output ->
            tmp.inputStream().use { it.copyTo(output) }
        }
        tmp.delete()
        Log.info("&lcVersion downloaded, exiting. Note that if you are not using a auto-restart script, the server will not restart automatically.")
        exitProcess(2)
    }
    broadcast("[yellow]服务器新版本{version}下载完成,将在本局游戏后自动重启更新".with("version" to version))
}

listen<EventType.ResetEvent> {
    updateCallback?.invoke()
}

command("forceUpdate", "强制更新服务器版本") {
    permission = dotId
    usage = "<url>"
    body {
        arg.firstOrNull()?.let { kotlin.runCatching { URL(it) }.getOrNull() } ?: replyUsage()
        reply("[green]正在后台处理中".with())
        launch {
            try {
                update("管理员手动升级", arg.first())
            } catch (e: Throwable) {
                reply("[red]升级失败{e}".with("e" to e))
                e.printStackTrace()
            }
        }
    }
}

