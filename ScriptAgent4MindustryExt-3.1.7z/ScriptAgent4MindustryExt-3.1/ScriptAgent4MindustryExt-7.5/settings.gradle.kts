if (rootDir.parentFile.name == "branches")
    rootProject.name = rootDir.name
else
    rootProject.name = "ScriptAgent4Mindustry"

